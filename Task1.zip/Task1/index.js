var outBox = document.getElementById("outBox");
var time = document.getElementById("time");
var blue = document.getElementById("blue");
var red = document.getElementById("red");
var orange = document.getElementById("orange");
var inner = document.getElementById("inner");
var btn_status = 0;
var hour = 0;
var min = 0;
var sec = 0;
var curr_time = "";
blue.addEventListener("click", () => {
    if (btn_status == 0) {
        orange.disabled = false;
        outBox.style.backgroundColor = "#00A800";
        blue.setAttribute('class', 'btn red');
        btn_status = 1;
        blue.innerHTML = "STOP";
        timer = setInterval(() => {
            curr_time = "";
            sec = sec + 1;
            if (hour < 10) {
                curr_time += "0" + hour + ":";
            } else {
                curr_time += hour + ":";
            }
            if (min < 10) {
                curr_time += "0" + min + ":";
            } else {
                curr_time += min + ":";
            }
            if (sec < 10) {
                curr_time += "0" + sec;
            } else {
                curr_time += sec;
            }
            time.innerHTML = curr_time;

            if (sec == 59) {
                min = min + 1;
                sec = 0;
            }

            if (min == 60) {
                hour = hour + 1;
                min = 0;
            }

        }, 1000)
    }
    else {
        outBox.style.backgroundColor = "#E50000";
        blue.setAttribute('class', 'btn blue');
        btn_status = 0;
        blue.innerHTML = "START";
        clearInterval(timer);
    }
});

orange.addEventListener("click", () => {
    inner.innerHTML += "<br>" + curr_time;
    outBox.style.backgroundColor = "#FFD700";
    setTimeout(() => {
        outBox.style.backgroundColor = "#00A800";
    }, 500);
})

red.addEventListener("click", () => {
    outBox.style.backgroundColor = "#111111";
    sec = min = hour = 0;
    blue.setAttribute('class', 'btn blue');
    btn_status = 0;
    blue.innerHTML = "START";
    clearInterval(timer);
    time.innerHTML = "00:00:00";
    inner.innerHTML = "LAPS"
    orange.disabled = true;
})